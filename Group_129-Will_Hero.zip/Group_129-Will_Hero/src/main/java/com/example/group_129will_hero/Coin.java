package com.example.group_129will_hero;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

import java.util.Objects;

public class Coin {
    private int count;
    private final ImageView fx;

    public boolean isCollide() {
        return collide;
    }

    public void setCollide(boolean collide) {
        this.collide = collide;
    }

    private boolean collide;
    public void add(AnchorPane pane){
        pane.getChildren().add(fx);
    }
    public Coin(double X, double Y){
        fx = new ImageView();
        fx.setImage(new Image("Coin.png",true));
        fx.setFitWidth(16);
        fx.setFitHeight(18);
        fx.setLayoutX(X);
        fx.setLayoutY(Y);
        collide = false;
    }
    public ImageView getFx() {
        return fx;
    }

    public void setCount(int count) {
        this.count += count;
    }

    public int getCount() {
        return count;
    }
}
