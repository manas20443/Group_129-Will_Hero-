package com.example.group_129will_hero;

import javafx.fxml.FXML;
import javafx.scene.image.ImageView;

public class Trees {
    @FXML
    private ImageView t1;
    @FXML
    private ImageView t2;
    @FXML
    private ImageView t3;
    @FXML
    private ImageView t4;
    @FXML
    private ImageView t5;
    @FXML
    private ImageView t6;
    @FXML
    private ImageView t7;
    @FXML
    private ImageView t8;
    @FXML
    private ImageView t9;
    @FXML
    private ImageView t10;
    @FXML
    private ImageView t11;
    @FXML
    private ImageView t12;
    @FXML
    private ImageView t13;

}
