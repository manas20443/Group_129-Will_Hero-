package com.example.group_129will_hero;

import java.io.Serial;
import java.io.Serializable;

public class saveGame implements Serializable {
    public int score;
    public int coinScore;
    public double heroX;
    public double heroY;
    public double sceneX;

    public boolean paused =false;
}
