package com.example.group_129will_hero;

import javafx.fxml.FXML;
import javafx.scene.image.ImageView;

import java.util.ArrayList;

public class Orcs {

    private ImageView fxid;

    private ArrayList <ImageView> imgvw = new ArrayList<>();

    public ArrayList<ImageView> getImgvw() {
        return imgvw;
    }
}
