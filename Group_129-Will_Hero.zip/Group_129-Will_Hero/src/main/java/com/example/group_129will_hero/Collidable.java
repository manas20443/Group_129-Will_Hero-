package com.example.group_129will_hero;

import javafx.scene.image.ImageView;

public interface Collidable {
    public boolean doesCollide(ImageView i, ImageView j);
}
